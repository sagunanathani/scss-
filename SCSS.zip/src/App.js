import React from "react";
// import './App.css';
// import "../../../SCSS/my-app/src/css/style.css"

const App = () => {
    return (
        <div>
            <h1> I AM SASS AND SCSS</h1>
            <p>This property specifies what kind of border to display:</p>
        </div>
    )
};

export default App;
